// $com CC $@ -o $* -lsocket -lnsl -library=iostream
//
// File:        tcp-server.C
// Author:      K. Reek
// Modified by: Narayan J. Kulkarni
// Description: Server, full duplex TCP connection
// Usage:       tcp-server port
//              where 'port' is the well-known port number to use.
//
// This program uses TCP to establish connections with clients and process
// requests.
//

#include "stdafx.h"
#include <iostream>
using namespace std;
#include <winsock.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>

#define PORT_MIN        1024
#define PORT_MAX        65535
#define bzero(p, l) memset(p, 0, l)

int main( int ac, char **av ){
        SOCKET     s;              // file descriptor for our socket
        struct  sockaddr_in server; // server's IP address
        int     port;           // server's port number

	WSADATA wsaData;
	WSAStartup(MAKEWORD(2, 2), &wsaData);

        //
        // Make sure that the port argument was given
        //
        if( ac < 2 ){
                cout<<"Usage: "<<av[ 0 ]<< " port"<<endl;
                exit( EXIT_FAILURE );
        }


        //
        // Get the port number, and make sure that it is legitimate
        //
        port = atoi( av[ 1 ] );
        if( port < PORT_MIN || port > PORT_MAX ){
               cout<<"Invalid port number: "<< av[ 2]<<endl;
                exit( EXIT_FAILURE );
        }

        //
        // Create a stream (TCP) socket.  The protocol argument is left 0 to
        // allow the system to choose an appropriate protocol.
        //
        s = socket( AF_INET, SOCK_STREAM, 0 );
        if( s < 0 ){
                cout<<"socket creation bombed!: "<<strerror( errno )<<endl;
                exit( EXIT_FAILURE );
        }

        //
        // Fill in the addr structure with the port number given by
        // the user.  The OS kernel will fill in the host portion of
        // the address depending on which network interface is used.
        //
        bzero( &server, sizeof( server ) );
        server.sin_family = AF_INET;
        server.sin_port = htons( port );

        //
        // Bind this port number to this socket so that other programs can
        // connect to this socket by specifying the port number.
        //
        if( bind( s, (struct sockaddr *)&server, sizeof( server ) ) < 0 ){
                 cout<<"bind: "<<strerror( errno )<<endl;
                exit( EXIT_FAILURE );
        }

        //
        // Make this socket passive, that is, one that awaits connections
        // rather than initiating them.
        //
        if( listen( s, 1 ) < 0 ){
                 cout<<"listen: "<<strerror( errno )<<endl;
                exit( EXIT_FAILURE );
        }

        //
        // Now start serving clients
        //
        for(;;){
                int     ns;             // new socket for the connection
                char    buf[512];       // data buffer
                int     len;            // buffer length

                //
                // Wait for a client's connection request
                //
                cout<<"Waiting for a connection ..."<<endl;
                ns = accept( s, 0, 0 );
                if( ns < 0 ){
                cout<<"accept: "<<strerror( errno )<<endl;                  
                        continue;
                }

                cout<<"Connected to client"<<endl;

                //
                // Now read and respond to messages until end of file is
                // reached (which means the client closed the connection).
                //
                // NOTE: This code assumes that the data is written by the
                // client all at once, and that it arrives all at once!  If
                // it doesn't, we'll just look at the first part of the
                // data, and we'll return the wrong result.  In addition,
                // the remaining data may be concatenated with the next
                // thing that the client writes, ruining that reply as well.
                //
                len = recv( ns, buf, sizeof( buf ),0 );
                while( len > 0 ){
                        //
                        // Print the message we got
                        //
                        cout<<"Client sent: "<<buf<<endl;

                        //
                        // Send back the message length.
                        //
  
						cout<<"Sending length of the string to client: "<<len<<endl;
                        len = ntohl(len);
                        if( send( ns, (char*)&len, sizeof(len),0) !=sizeof(len)) {
                                cout<<"write: "<< strerror( errno )<<endl;
                                exit( EXIT_FAILURE );
                        }

                        //
                        // Read the next message
                        //
                        len = recv( ns, buf, sizeof( buf ),0 );
                }

                //
                //
                if( len < 0 ){
                        cout<<"read: "<<strerror( errno )<<endl;
                        exit( EXIT_FAILURE );
                }

                //
                // When client closes connection, the read returns with zero bytes.
                // End of data -- the client closed the connection.
                // Close the connection socket and resume listening on
                // the original socket.
                //
                  closesocket( ns );
                cout<<"Connection closed."<<endl;
        }
}
